﻿param([ValidateSet('apply','restore','status')][string]$Action='status',[Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$source=Join-Path $root 'tips.json'
$target=Join-Path $GamePath 'starsector-core\data\strings\tips.json'
$stateRoot=Join-Path $env:LOCALAPPDATA 'Starsector_KoreanReading_Manager'
$state=Join-Path $stateRoot 'tips_backup_state.json'
$backup=Join-Path $stateRoot 'tips_original_v081.json'
$vanillaHash='A7A05BFA76F7EF72A9AD080B5B968B60BD5E8C1CCB37B26553BAAB1D01301529'
$koreanHash='3E34B81009FF16BA6EE1986FCAFF6058B234903E41DD35B69EC15E41956C7336'
$knownKoreanHashes=@($koreanHash,'13EDB8C66E02EFAD14113AF8855DB067F1D7ABF5005737AC483EB48326BEEEE7')
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToUpperInvariant()}
if($Action -eq 'restore' -and !(Test-Path -LiteralPath $state)){'NOT_MANAGED';exit 0}
if(!(Test-Path -LiteralPath $target)){throw '기본 게임 팁 파일을 찾지 못했습니다. 다른 파일을 변경하지 않습니다.'}
if(!(Test-Path -LiteralPath $source)){throw '번역된 팁 파일이 없습니다.'}
if((Hash $source) -ne $koreanHash){throw '패키지 내 번역 파일 해시 오류.'}
$cur=Hash $target
if($Action -eq 'status'){
 if($cur -eq $vanillaHash){'VANILLA';exit 0}
 if($cur -eq $koreanHash){'KOREAN';exit 0}
 'UNKNOWN';exit 3
}
# Reconcile a stale record only if target and backup are verified vanilla and paths match.
if(($Action -in @('apply','restore')) -and (Test-Path -LiteralPath $state) -and $cur -eq $vanillaHash){
 $meta=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
 if($meta.game -eq $GamePath -and $meta.target -eq $target -and $meta.backup -eq $backup -and $meta.original -eq $vanillaHash -and $meta.installed -in $knownKoreanHashes -and (Test-Path -LiteralPath $backup) -and (Hash $backup) -eq $vanillaHash){
  Remove-Item -LiteralPath $state -Force
  if($Action -eq 'restore'){'ALREADY_VANILLA';exit 0}
  'STALE_RECORD_RECONCILED'
 }
}
if($Action -eq 'apply'){
 # Upgrade a verified prior tips installation without replacing its original backup.
 if($cur -ne $koreanHash -and $cur -in $knownKoreanHashes){
  if(!(Test-Path -LiteralPath $state)){throw '이전 팁 번역본의 설치 기록이 없습니다.'}
  $meta=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
  if($meta.game -ne $GamePath -or $meta.target -ne $target -or $meta.backup -ne $backup -or $meta.original -ne $vanillaHash -or $meta.installed -ne $cur -or !(Test-Path -LiteralPath $backup) -or (Hash $backup) -ne $vanillaHash){throw '이전 팁 설치 기록 또는 원본 백업 검증 실패.'}
  $tmp=$target+'.krtemp';$prior=$target+'.krprior'
  if((Test-Path -LiteralPath $tmp) -or (Test-Path -LiteralPath $prior)){throw '기존 임시 팁 파일이 남아 있습니다.'}
  try {
   Copy-Item -LiteralPath $target -Destination $prior
   Copy-Item -LiteralPath $source -Destination $tmp
   if((Hash $tmp) -ne $koreanHash){throw '임시 팁 검증 실패'}
   Move-Item -LiteralPath $tmp -Destination $target -Force
   if((Hash $target) -ne $koreanHash){throw '한글 팁 적용 검증 실패'}
   $meta.installed=$koreanHash
   $meta | ConvertTo-Json | Set-Content -LiteralPath $state -Encoding UTF8
   'UPDATED';exit 0
  } catch {
   if((Test-Path -LiteralPath $prior) -and (Hash $prior) -eq $cur){Copy-Item -LiteralPath $prior -Destination $target -Force}
   throw
  } finally {foreach($f in @($tmp,$prior)){if(Test-Path -LiteralPath $f){Remove-Item -LiteralPath $f -Force}}}
 }
 if($cur -eq $koreanHash){
  if(!(Test-Path -LiteralPath $state)){throw '현재 파일이 번역본이지만 이 설치기의 백업 기록이 없습니다. 덮어쓰지 않습니다.'}
  if(!(Test-Path -LiteralPath $backup) -or (Hash $backup) -ne $vanillaHash){throw '원본 복구용 백업이 없거나 손상됐습니다.'}
  'ALREADY_APPLIED';exit 0
 }
 if($cur -ne $vanillaHash){throw '팁 파일이 제공된 원본과 다릅니다. 타 패치/게임 버전을 보호하기 위해 변경하지 않습니다.'}
 if(Test-Path -LiteralPath $state){throw '기존 팁 백업 기록이 남아 있습니다. 직접 확인 전 중단합니다.'}
 New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
 Copy-Item -LiteralPath $target -Destination $backup -Force
 if((Hash $backup) -ne $vanillaHash){throw '원본 백업 검증 실패'}
 $tmp=$target+'.krtemp'
 try {
  Copy-Item -LiteralPath $source -Destination $tmp -Force
  if((Hash $tmp) -ne $koreanHash){throw '임시 팁 검증 실패'}
  Move-Item -LiteralPath $tmp -Destination $target -Force
  if((Hash $target) -ne $koreanHash){throw '한글 팁 적용 검증 실패'}
  @{game=$GamePath;target=$target;backup=$backup;original=$vanillaHash;installed=$koreanHash} | ConvertTo-Json | Set-Content -LiteralPath $state -Encoding UTF8
  'APPLIED';exit 0
 } catch {
  if(Test-Path -LiteralPath $backup){Copy-Item -LiteralPath $backup -Destination $target -Force}
  throw
 } finally {if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
if($Action -eq 'restore'){
 if(!(Test-Path -LiteralPath $state)){
  if($cur -eq $vanillaHash){'ALREADY_VANILLA';exit 0}
  throw '관리 대상이라는 기록이 없으므로 파일을 복원하지 않습니다.'
 }
 $meta=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
 if($meta.game -ne $GamePath -or $meta.target -ne $target){throw '백업 대상 경로 불일치'}
 if(!(Test-Path -LiteralPath $backup) -or (Hash $backup) -ne $vanillaHash){throw '백업이 유효하지 않습니다.'}
 if($meta.backup -ne $backup -or $meta.original -ne $vanillaHash -or $meta.installed -ne $cur -or $cur -notin $knownKoreanHashes){throw '설치 이후 팁 파일이 변경되었거나 설치 기록이 일치하지 않습니다. 덮어쓰지 않습니다.'}
 Copy-Item -LiteralPath $backup -Destination $target -Force
 if((Hash $target) -ne $vanillaHash){throw '복원 검증 실패'}
 Remove-Item -LiteralPath $state -Force
 Remove-Item -LiteralPath $backup -Force
 'RESTORED';exit 0
}
