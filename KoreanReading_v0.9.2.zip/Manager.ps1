﻿#requires -version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference='Stop'
# The game is normally installed under Program Files. Elevate before any writes.
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
 try {
  $engine=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $arguments='-NoProfile -ExecutionPolicy Bypass -STA -File "'+$PSCommandPath+'"'
  Start-Process -FilePath $engine -ArgumentList $arguments -Verb RunAs -ErrorAction Stop
 }catch{[System.Windows.Forms.MessageBox]::Show('관리자 권한이 필요합니다. UAC 승인 후 다시 실행해 주세요.','스타섹터 한글 패치') | Out-Null}
 exit
}
# Windows PowerShell 5.1: force readable output even on Korean systems.
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$payload=Join-Path $root 'KoreanReading_payload.zip'
$uiDir=Join-Path $root 'Optional_Core_UI'
$defaultPath='C:\Program Files (x86)\Fractal Softworks\Starsector'
$stateRoot=Join-Path $env:LOCALAPPDATA 'Starsector_KoreanReading_Manager'
$statePath=Join-Path $stateRoot 'state.json'
$script:game=$defaultPath
$script:state=$null

$form=New-Object System.Windows.Forms.Form
$form.Text='스타섹터 한국어 패치 관리 — v0.8.64'
$form.Size=New-Object System.Drawing.Size(800,585)
$form.MinimumSize=New-Object System.Drawing.Size(800,585)
$form.StartPosition='CenterScreen'
$form.Font=New-Object System.Drawing.Font('Malgun Gothic',10)
$label=New-Object System.Windows.Forms.Label
$label.Text='스타섹터 게임 설치 폴더'; $label.Location=New-Object System.Drawing.Point(20,16); $label.AutoSize=$true
$form.Controls.Add($label)
$pathBox=New-Object System.Windows.Forms.TextBox
$pathBox.Location=New-Object System.Drawing.Point(20,42);$pathBox.Size=New-Object System.Drawing.Size(630,28);$pathBox.Text=$defaultPath
$form.Controls.Add($pathBox)
$browse=New-Object System.Windows.Forms.Button
$browse.Text='찾아보기';$browse.Location=New-Object System.Drawing.Point(660,40);$browse.Size=New-Object System.Drawing.Size(90,30)
$form.Controls.Add($browse)
$status=New-Object System.Windows.Forms.Label
$status.Location=New-Object System.Drawing.Point(20,84);$status.Size=New-Object System.Drawing.Size(750,52)
$status.Text='상태 확인 중...';$status.ForeColor=[System.Drawing.Color]::DarkBlue
$form.Controls.Add($status)
$warn=New-Object System.Windows.Forms.Label
$warn.Location=New-Object System.Drawing.Point(20,146);$warn.Size=New-Object System.Drawing.Size(750,46)
$warn.ForeColor=[System.Drawing.Color]::DarkRed
$warn.Text="주의: 게임 버전이나 모드 구성 변경으로 세이브파일 호환 문제가 발생할 수 있습니다.`r`n설치 전 반드시 세이브파일을 백업해 주세요."
$form.Controls.Add($warn)
$note=New-Object System.Windows.Forms.Label
$note.Location=New-Object System.Drawing.Point(20,200);$note.Size=New-Object System.Drawing.Size(750,27)
$note.Text='게임 실행에 앞서 모드관리에서 활성화를 꼭 해주셔야 적용됩니다.'
$form.Controls.Add($note)
$installAll=New-Object System.Windows.Forms.Button
$installAll.Text='한글패치 설치 / 업데이트';$installAll.Location=New-Object System.Drawing.Point(20,244);$installAll.Size=New-Object System.Drawing.Size(350,43)
$form.Controls.Add($installAll)
$uninstallAll=New-Object System.Windows.Forms.Button
$uninstallAll.Text='한글패치 제거';$uninstallAll.Location=New-Object System.Drawing.Point(20,305);$uninstallAll.Size=New-Object System.Drawing.Size(350,43)
$form.Controls.Add($uninstallAll)
$exit=New-Object System.Windows.Forms.Button
$exit.Text='종료';$exit.Location=New-Object System.Drawing.Point(20,366);$exit.Size=New-Object System.Drawing.Size(350,43)
$form.Controls.Add($exit)
$log=New-Object System.Windows.Forms.TextBox
$log.Location=New-Object System.Drawing.Point(390,244);$log.Size=New-Object System.Drawing.Size(380,247)
$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical'
$form.Controls.Add($log)
$logPath=Join-Path $env:TEMP ('Starsector_KR_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.log')
function Say([string]$msg){
 $line="[$(Get-Date -Format 'HH:mm:ss')] $msg`r`n"
 $log.AppendText($line)
 try{[IO.File]::AppendAllText($logPath,$line,[Text.Encoding]::UTF8)}catch{}
}
function Done([string]$s){[System.Windows.Forms.MessageBox]::Show($form,$s,'패치 완료!',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null}
function Alert([string]$s){[System.Windows.Forms.MessageBox]::Show($form,$s,'스타섹터 한국어 패치') | Out-Null}
function JarHelp {return "JAR 문제가 발생한다면 게임 버전이 일치하는지 확인해주세요. 그래도 계속 문제가 발생한다면 게임을 완전 삭제 후 재설치 해주세요.`r`n`r`n재설치 전 세이브파일, 모드 구성과 기존 원본 JAR 백업을 안전하게 보관해 주세요. 확인되지 않은 JAR는 임의로 수정하거나 복원하지 않습니다."}
function Ask([string]$s){return ([System.Windows.Forms.MessageBox]::Show($form,$s,'확인',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question) -eq [System.Windows.Forms.DialogResult]::Yes)}
function GamePath {return $pathBox.Text.Trim().Trim('"').TrimEnd('\')}
function CheckGame {
 $p=GamePath
 if(!(Test-Path -LiteralPath (Join-Path $p 'starsector-core\starfarer_obf.jar') -PathType Leaf)){throw '스타섹터 설치 폴더가 아닙니다. starsector-core\starfarer_obf.jar 파일이 없습니다.'}
 return $p
}
function LoadState {
 $script:state=$null
 if(Test-Path -LiteralPath $statePath){$script:state=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json}
}
function HashFile([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash}
function GetManifest([string]$folder){
 $m=@{}
 Get-ChildItem -LiteralPath $folder -File -Recurse | ForEach-Object {
  $rel=$_.FullName.Substring($folder.Length+1).Replace('\','/')
  $m[$rel]=(HashFile $_.FullName)
 }
 return $m
}
function MatchesManifest([string]$folder,$stateManifest){
 if(!(Test-Path -LiteralPath $folder -PathType Container)){return $false}
 $now=GetManifest $folder
 $old=@{};foreach($prop in $stateManifest.PSObject.Properties){$old[$prop.Name]=$prop.Value}
 if($now.Count -ne $old.Count){return $false}
 foreach($key in $old.Keys){if(!($now.ContainsKey($key)) -or $now[$key] -ne $old[$key]){return $false}}
 return $true
}
function UpdateStatus {
 LoadState
 $p=GamePath
 $folder=Join-Path $p 'mods\KoreanReading'
 $s=''
 if(!(Test-Path -LiteralPath (Join-Path $p 'starsector-core\starfarer_obf.jar'))){$s='게임 경로를 확인해 주세요.'}
 elseif($script:state -and $script:state.game -eq $p){
  if(MatchesManifest $folder $script:state.manifest){$s='기본 패치: 이 설치기로 설치됨 (정상)'}
  else{$s='기본 패치: 파일이 변경되었거나 누락됨 (제거 전 확인 필요)'}
 }elseif(Test-Path -LiteralPath $folder){$s='기본 패치: 기존 수동 설치본 발견 (관리 이력 없음)'}
 else{$s='기본 패치: 미설치'}
 $status.Text=$s + "`r`nUI 및 자동 장착 번역은 두 JAR의 원문을 확인한 뒤 적용합니다. 적용 전 원본은 백업합니다."
}
function PrepareStateRoot {New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null}
function RegisterShortcut {
 try {
  $menu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  $sc=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $menu '스타섹터 한글 패치 관리.lnk'))
  $sc.TargetPath=(Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe')
  $sc.Arguments='-NoProfile -ExecutionPolicy Bypass -STA -File "'+(Join-Path $root 'Manager.ps1')+'"'
  $sc.WorkingDirectory=$root
  $sc.Description='스타섹터 한글 패치 통합 설치·제거'
  $sc.Save()
  Say '시작 메뉴에 한글 패치 관리 바로가기를 만들었습니다.'
 }catch {Say ('바로가기 생성 생략: '+$_.Exception.Message)}
}

function TipsAction([string]$action){
 $p=CheckGame
 $scriptFile=Join-Path $root 'Optional_Core_Tips\Manage_Tips.ps1'
 if(!(Test-Path -LiteralPath $scriptFile)){Say '팁 적용 구성 요소가 없으므로 원본을 유지합니다.';return $false}
 $engine=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $psi=New-Object System.Diagnostics.ProcessStartInfo
 $psi.FileName=$engine
 $psi.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$scriptFile+'" -Action '+$action+' -GamePath "'+$p+'"'
 $psi.WorkingDirectory=(Join-Path $root 'Optional_Core_Tips')
 $psi.UseShellExecute=$false;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.CreateNoWindow=$true
 $psi.StandardOutputEncoding=[System.Text.Encoding]::UTF8;$psi.StandardErrorEncoding=[System.Text.Encoding]::UTF8
 $proc=[System.Diagnostics.Process]::Start($psi)
 $outTask=$proc.StandardOutput.ReadToEndAsync();$errTask=$proc.StandardError.ReadToEndAsync();$proc.WaitForExit();$stdout=$outTask.GetAwaiter().GetResult();$stderr=$errTask.GetAwaiter().GetResult()
 if($stdout.Trim()){Say ('팁: '+$stdout.Trim())}
 if($stderr.Trim()){Say ('팁: '+$stderr.Trim())}
 if($proc.ExitCode -ne 0){Say ('팁 처리 보류 (코드 '+$proc.ExitCode+'). 다른 설치 항목에는 영향이 없습니다.' );return $false}
 return $true
}


function NewGameTextAction([string]$action){
 $p=CheckGame
 $scriptFile=Join-Path $root 'Optional_Core_NewGame\Manage_NewGame.ps1'
 if(!(Test-Path -LiteralPath $scriptFile)){Say '새 게임 표시문구 패처가 없어 원본을 유지합니다.';return $false}
 $engine=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $psi=New-Object System.Diagnostics.ProcessStartInfo
 $psi.FileName=$engine
 $psi.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$scriptFile+'" -Action '+$action+' -GamePath "'+$p+'"'
 $psi.WorkingDirectory=(Join-Path $root 'Optional_Core_NewGame')
 $psi.UseShellExecute=$false;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.CreateNoWindow=$true
 $psi.StandardOutputEncoding=[System.Text.Encoding]::UTF8;$psi.StandardErrorEncoding=[System.Text.Encoding]::UTF8
 $proc=[System.Diagnostics.Process]::Start($psi)
 $outTask=$proc.StandardOutput.ReadToEndAsync();$errTask=$proc.StandardError.ReadToEndAsync();$proc.WaitForExit();$stdout=$outTask.GetAwaiter().GetResult();$stderr=$errTask.GetAwaiter().GetResult()
 if($stdout.Trim()){Say ('새 게임 문구: '+$stdout.Trim())}
 if($stderr.Trim()){Say ('새 게임 문구: '+$stderr.Trim())}
 if($proc.ExitCode -ne 0){Say ('새 게임 문구 적용/복원 보류 (코드 '+$proc.ExitCode+'). 원본을 확인해 주세요.');return $false}
 return $true
}

function InstallBase {
 $p=CheckGame
 LoadState
 if($script:state -and $script:state.game -ne $p){throw "다른 게임 경로에 설치 기록이 있습니다: $($script:state.game). 먼저 그 경로의 패치를 제거해 주세요."}
 $dest=Join-Path $p 'mods\KoreanReading'
 if(Test-Path -LiteralPath $dest){
  if($script:state){
   if(!(MatchesManifest $dest $script:state.manifest)){throw '기존 설치 파일이 변경됐습니다. 사용자 수정을 보호하기 위해 자동 덮어쓰기를 중단했습니다.'}
  }elseif(!(Ask '기존 KoreanReading 폴더를 발견했습니다. 기존 폴더를 백업한 뒤 새 버전으로 교체하고 관리 대상으로 등록할까요?')){return $false}
 }
 $temp=Join-Path $env:TEMP ('KRInstall_'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $temp -Force | Out-Null
 try{
  Expand-Archive -LiteralPath $payload -DestinationPath $temp -Force
  $source=Join-Path $temp 'KoreanReading'
  if(!(Test-Path (Join-Path $source 'mod_info.json'))){throw '배포 파일의 모드 정보가 없습니다. 설치를 취소합니다.'}
  $newManifest=GetManifest $source
  PrepareStateRoot
  $backup=''
  $oldBackup=''
  if($script:state){$oldBackup=[string]$script:state.previousBackup}
  if(Test-Path -LiteralPath $dest){
   $backup=Join-Path $stateRoot ('previous_'+(Get-Date -Format 'yyyyMMdd_HHmmss'))
   Move-Item -LiteralPath $dest -Destination $backup
  }
  try {
   New-Item -ItemType Directory -Path (Join-Path $p 'mods') -Force | Out-Null
   Copy-Item -LiteralPath $source -Destination $dest -Recurse
   if(!(MatchesManifest $dest ([pscustomobject]$newManifest))){throw '설치 파일 검증에 실패했습니다.'}
   $preserveBackup=$backup
   if($script:state){$preserveBackup=$oldBackup}
   $obj=[ordered]@{game=$p;version='0.8.64';manifest=$newManifest;previousBackup=$preserveBackup}
   $obj | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $statePath -Encoding UTF8
   if($script:state -and $backup -and (Test-Path $backup)){Remove-Item -LiteralPath $backup -Recurse -Force; $backup=''}
  }catch {
   if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force -Recurse}
   if($backup -and (Test-Path $backup)){Move-Item -LiteralPath $backup -Destination $dest}
   throw
  }
  RegisterShortcut
  $script:tipsOK=TipsAction 'apply'
  $script:newGameOK=NewGameTextAction 'apply'
  Say '기본 한글 패치 설치 완료. 게임 런처의 모드관리에서 Korean Reading을 활성화하세요.'
  if($backup){Say "이전 설치본 백업: $backup"}
  return $true
 }finally{if(Test-Path $temp){Remove-Item -LiteralPath $temp -Force -Recurse}}
}
function UninstallBase([bool]$complete=$false) {
 $p=CheckGame
 LoadState
 $dest=Join-Path $p 'mods\KoreanReading'
 if(!$script:state -or $script:state.game -ne $p){throw '이 설치기로 관리 중인 기본 패치가 없습니다. 수동 설치본은 보호를 위해 자동 삭제하지 않습니다.'}
 if(!(MatchesManifest $dest $script:state.manifest)){throw '설치 후 파일이 수정되었거나 추가 파일이 있습니다. 다른 파일을 삭제하지 않도록 자동 제거를 중단했습니다.'}
 if(!$complete -and !(Ask '기본 한글 패치를 제거할까요?')){return}
 if(!(NewGameTextAction 'restore')){throw '시작 화면 장교 문구 백업 복구가 확인되지 않아 삭제를 중단했습니다.'}
 if(!(TipsAction 'restore')){throw '메인 메뉴 팁 백업 복구가 확인되지 않았으므로 삭제를 중단했습니다. 팁 파일 상태를 확인하세요.'}
 Remove-Item -LiteralPath $dest -Recurse -Force
 if($script:state.previousBackup -and (Test-Path -LiteralPath $script:state.previousBackup)){
  if(!$complete -and (Ask '설치 전에 있던 기존 KoreanReading 폴더 백업이 있습니다. 그 폴더를 복구할까요?')){
   Move-Item -LiteralPath $script:state.previousBackup -Destination $dest
  }else{Say "이전 버전 백업 유지: $($script:state.previousBackup)"}
 }
 Remove-Item -LiteralPath $statePath -Force
 Say '기본 한글 패치 제거 완료.'
}
function CheckWritableJars([string]$p){
 $core=Join-Path $p 'starsector-core'
 foreach($name in @('starfarer_obf.jar','starfarer.api.jar')){
  $target=Join-Path $core $name
  $handle=$null
  try{$handle=[IO.File]::Open($target,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
  catch{throw "JAR 파일을 독점적으로 열 수 없습니다: $target`r`n게임과 런처를 종료하고 파일 권한/읽기 전용 속성을 확인하세요.`r`n$($_.Exception.Message)"}
  finally{if($handle){$handle.Dispose()}}
 }
 $probe=Join-Path $core ('kr-probe-'+[guid]::NewGuid().ToString('N')+'.tmp')
 $probe2=$probe+'.dest'
 $probeBackup=$probe+'.bak'
 try{
  [IO.File]::WriteAllText($probe,'probe');[IO.File]::WriteAllText($probe2,'probe2')
  [IO.File]::Replace($probe,$probe2,$probeBackup)
 }catch{throw "게임 폴더 파일 교체 검사 실패: $($_.Exception.Message)"}
 finally{foreach($f in @($probe,$probe2,$probeBackup)){if(Test-Path -LiteralPath $f){Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue}}}
 Say '관리자 권한 / JAR 접근 / 임시 파일 교체 사전 검사 통과.'
}
function JavaExe([string]$p){
 foreach($s in @('jre\bin\java.exe','jdk\bin\java.exe','jre\bin\javaw.exe','jdk\bin\javaw.exe')){
  $a=Join-Path $p $s;if(Test-Path -LiteralPath $a){return $a}
 }
 $j=Get-Command java.exe -ErrorAction SilentlyContinue
 if($j){return $j.Source}
 throw 'Java 실행 파일을 찾지 못했습니다. 게임에 동봉된 Java 구성요소를 확인해 주세요.'
}
function RunUiCore([string]$action){
 $p=CheckGame;$java=JavaExe $p
 $jar=Join-Path $uiDir 'KrUiPatcher.jar'
 if(!(Test-Path -LiteralPath $jar)){throw 'UI 설치기 파일이 없습니다. 전체 압축파일을 다시 풀어 주세요.'}
 $psi=New-Object System.Diagnostics.ProcessStartInfo
 $psi.FileName=$java
 $psi.Arguments='-Dfile.encoding=UTF-8 -jar "'+$jar+'" '+$action+' "'+$p+'"'
 $psi.WorkingDirectory=$uiDir
 $psi.UseShellExecute=$false;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.CreateNoWindow=$true
 $psi.StandardOutputEncoding=[System.Text.Encoding]::UTF8;$psi.StandardErrorEncoding=[System.Text.Encoding]::UTF8
 $proc=[System.Diagnostics.Process]::Start($psi)
 $outTask=$proc.StandardOutput.ReadToEndAsync();$errTask=$proc.StandardError.ReadToEndAsync();$proc.WaitForExit();$stdout=$outTask.GetAwaiter().GetResult();$stderr=$errTask.GetAwaiter().GetResult()
 Say ($stdout.Trim());if($stderr.Trim()){Say ($stderr.Trim())}
 return $proc.ExitCode
}
function RunApi([string]$action){
 $p=CheckGame;$java=JavaExe $p
 $jar=Join-Path $root 'Optional_Core_API\KrApiPatcher.jar'
 if(!(Test-Path -LiteralPath $jar)){throw 'API 번역 패처가 없습니다. ZIP 압축을 다시 풀어 주세요.'}
 $psi=New-Object System.Diagnostics.ProcessStartInfo
 $psi.FileName=$java
 $psi.Arguments='-Dfile.encoding=UTF-8 -jar "'+$jar+'" '+$action+' "'+$p+'"'
 $psi.WorkingDirectory=(Join-Path $root 'Optional_Core_API')
 $psi.UseShellExecute=$false;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.CreateNoWindow=$true
 $psi.StandardOutputEncoding=[System.Text.Encoding]::UTF8;$psi.StandardErrorEncoding=[System.Text.Encoding]::UTF8
 $proc=[System.Diagnostics.Process]::Start($psi)
 $outTask=$proc.StandardOutput.ReadToEndAsync();$errTask=$proc.StandardError.ReadToEndAsync();$proc.WaitForExit();$stdout=$outTask.GetAwaiter().GetResult();$stderr=$errTask.GetAwaiter().GetResult()
 Say ($stdout.Trim());if($stderr.Trim()){Say ($stderr.Trim())}
 return $proc.ExitCode
}
function RunUi([string]$action){
 if($action -eq 'status'){
  $u=RunUiCore 'status';$a=RunApi 'status'
  if($u -notin @(0,2) -or $a -notin @(0,2)){return 4}
  if($u -eq 2 -or $a -eq 2){return 2}
  return 0
 }
 if($action -eq 'apply'){
  $u=RunUiCore 'status';$a=RunApi 'status'
  if($u -ne 0 -or $a -ne 0){Say '둘 중 하나의 JAR가 설치 가능 상태가 아닙니다.';return 4}
  $uc=RunUiCore 'apply';if($uc -ne 0){return $uc}
  $ac=RunApi 'apply'
  if($ac -ne 0){
   Say 'API 설치 실패: 기존 UI JAR를 자동 원복합니다.'
   $undo=RunUiCore 'restore'
   if($undo -ne 0){Say 'UI JAR 자동 복원 실패: 수동 점검 필요.'}
   return $ac
  }
  return 0
 }
 if($action -eq 'restore'){
  $u=RunUiCore 'status';$a=RunApi 'status'
  if($u -notin @(0,2) -or $a -notin @(0,2)){return 4}
  if($a -eq 2){$ar=RunApi 'restore';if($ar -ne 0){return $ar}}
  if($u -eq 2){$ur=RunUiCore 'restore';if($ur -ne 0){return $ur}}
  return 0
 }
 throw '지원하지 않는 명령입니다.'
}
function WrapAction([scriptblock]$job){
 try {& $job;UpdateStatus}
 catch{Say ('오류: '+$_.Exception.Message);Alert $_.Exception.Message;UpdateStatus}
}
function InstallAll {
 $p=CheckGame
 CheckWritableJars $p
 $code=RunUi 'status'
 if($code -notin @(0,2)){throw "JAR 호환성 검사 실패 (코드 $code). 기본 패치만 설치하지 않습니다.`r`n$(JarHelp)"}
 if(!(Ask '한글패치를 설치 / 업데이트할까요? 기본 모드와 두 JAR를 함께 설치하며, 기존 JAR 패치는 원본으로 복원 후 갱신합니다.')){return}
 if(!(InstallBase)){Say '설치 취소.';return}
 if($code -eq 2){if((RunUi 'restore') -ne 0){throw '기존 JAR 복원 실패. 기본 모드는 설치되었으나 전체 설치는 미완료입니다.'}}
 if((RunUi 'apply') -ne 0){throw "JAR 설치 실패. 기본 모드는 설치되었으나 전체 설치는 미완료입니다. 게임/런처 종료 및 파일 잠금을 확인하세요.`r`n상세 로그: $logPath"}
 if((RunUiCore 'status') -ne 2 -or (RunApi 'status') -ne 2){throw '두 JAR의 설치 상태 검증 실패. 전체 설치 완료로 표시하지 않습니다.'}
 if(!$script:tipsOK -or !$script:newGameOK){
  Alert "기본 모드와 두 JAR는 설치되었습니다. 일부 부가 문구 적용이 보류되었습니다. 로그를 확인해 주세요.`r`n게임 런처에서 Korean Reading 모드를 활성화해 주세요."
  return
 }
 Done "한글패치 설치 완료!`r`n게임 런처에서 Korean Reading 모드를 활성화해 주세요."
}
function UninstallAll {
 $p=CheckGame
 CheckWritableJars $p
 $code=RunUi 'status'
 LoadState
 $managed=($script:state -and $script:state.game -eq $p)
 if(!$managed -and !(Test-Path -LiteralPath (Join-Path $p 'mods\KoreanReading')) -and $code -eq 0 -and !(Test-Path (Join-Path $stateRoot 'tips_backup_state.json')) -and !(Test-Path (Join-Path $stateRoot 'newgame_officer_v084_state.json'))){
  Alert '설치된 한글 패치를 찾을 수 없습니다. 이미 제거되었거나 설치 기록이 없을 수 있습니다.'
  Say '제거할 한글 패치가 없습니다.';return
 }
 if($code -notin @(0,2)) {
  throw "UI 패치의 원본 백업 또는 설치 상태를 확인할 수 없습니다 (상태 코드 $code). 설치된 JAR를 보호하기 위해 자동 제거하지 않습니다. 기존 설치기의 백업 파일이나 설치 기록을 확인해 주세요.`r`n`r`n$(JarHelp)"
 }
 if(!$managed -and (Test-Path -LiteralPath (Join-Path $p 'mods\KoreanReading'))){
  throw '기본 한글 패치가 수동 설치본입니다. 다른 파일을 보호하기 위해 자동 삭제하지 않습니다.'
 }
 if(!(Ask 'UI 한패를 원상복구하고, 이 설치기로 관리 중인 기본 한패를 완전히 제거할까요? 원본 JAR 백업은 복원 후 정리됩니다.')){return}
 if($code -eq 2){
  $r=RunUi 'restore';if($r -ne 0){throw "UI 원상복구에 실패해 기본 패치 제거를 중단했습니다.`r`n`r`n$(JarHelp)"}
  Say 'UI 원본 JAR 복원 완료.'
 }
 if($managed){UninstallBase $true} else {
  if(!(NewGameTextAction 'restore')){throw '새 게임 문구 원본 복원 실패'}
  if(!(TipsAction 'restore')){throw '팁 원본 복원 실패'}
  Say '기본 한글 패치 설치 기록이 없습니다.'
 }
 Say '완전 제거 작업이 종료되었습니다. 외부 글꼴 보완 패치나 수동 파일은 별도로 확인하세요.'
 Done '한글패치 제거 완료! 관리 대상 원본 파일을 복원했습니다.'
}
$browse.Add_Click({$d=New-Object System.Windows.Forms.FolderBrowserDialog;$d.Description='스타섹터 설치 폴더 선택';$d.SelectedPath=(GamePath);if($d.ShowDialog() -eq 'OK'){$pathBox.Text=$d.SelectedPath;UpdateStatus}})
$installAll.Add_Click({WrapAction {InstallAll}})
$uninstallAll.Add_Click({WrapAction {UninstallAll}})
$exit.Add_Click({$form.Close()})
$pathBox.Add_Leave({UpdateStatus})
UpdateStatus
Say '관리 프로그램 준비 완료. 설치·제거 전 게임을 종료하고 세이브파일을 백업하세요.'
Say "상세 로그 파일: $logPath"
[void]$form.ShowDialog()
