@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Manager.ps1" (
 echo [ERROR] Manager.ps1 missing. Extract entire ZIP.
 pause
 exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Manager.ps1"
set "KR_EXIT=%ERRORLEVEL%"
if not "%KR_EXIT%"=="0" (
 echo.
 echo [ERROR] Manager failed, code: %KR_EXIT%
 pause
)
endlocal
