﻿param([ValidateSet('apply','restore','status')][string]$Action='status',[Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$target=Join-Path $GamePath 'starsector-core\data\campaign\rules.csv'
$stateDir=Join-Path $env:LOCALAPPDATA 'Starsector_KoreanReading_Manager'
$state=Join-Path $stateDir 'newgame_officer_v084_state.json'
$backup=Join-Path $stateDir 'newgame_officer_v084_original_rules.csv'
function Hash([string]$f){(Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToUpperInvariant()}
function Count([string]$s,[string]$t){([regex]::Matches($s,[regex]::Escape($t))).Count}
# Latin-1 maps each byte to one code point, so unknown bytes remain unchanged.
# UTF-8 Korean is deliberately represented as its raw byte sequence in Latin-1.
$latin=[System.Text.Encoding]::GetEncoding(28591)
$utf=[System.Text.Encoding]::UTF8
$old1='Acquired level 1 officer'
$old2='SetTextHighlights ""level 1 officer""'
$new1=$latin.GetString($utf.GetBytes('1레벨 장교 영입'))
$new2='SetTextHighlights ""'+$latin.GetString($utf.GetBytes('1레벨 장교'))+'""'
if($Action -eq 'restore' -and !(Test-Path -LiteralPath $state)){'NOT_MANAGED';exit 0}
if(!(Test-Path -LiteralPath $target)){throw '게임 원본 rules.csv 없음. 변경하지 않음.'}
# Reconcile only a verified original belonging to this game path.
if(($Action -in @('apply','restore')) -and (Test-Path -LiteralPath $state)){
 $meta=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
 if($meta.game -ne $GamePath){throw '다른 게임 경로 백업 기록'}
 if((Test-Path -LiteralPath $backup) -and (Hash $backup) -eq $meta.originalHash -and (Hash $target) -eq $meta.originalHash){
  Remove-Item -LiteralPath $state -Force
  if($Action -eq 'restore'){'ALREADY_VANILLA';exit 0}
  'STALE_RECORD_RECONCILED'
 }
}
if($Action -eq 'apply'){
 if(Test-Path -LiteralPath $state){
  $prev=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
  if((Hash $target) -eq $prev.patchedHash -and (Test-Path -LiteralPath $backup) -and (Hash $backup) -eq $prev.originalHash){'ALREADY_APPLIED';exit 0}
  throw '이전 설치 기록과 현재 파일이 다르다. 다른 파일을 덮어쓰지 않음.'
 }
 $raw=[System.IO.File]::ReadAllBytes($target)
 $str=$latin.GetString($raw)
 if((Count $str $old1) -ne 2 -or (Count $str $old2) -ne 2 -or (Count $str 'ngcMercPicked') -lt 1 -or (Count $str 'ngcKitePicked') -lt 1){throw '원본 예상 문구/시작 선택지 수 불일치: 변경 보류'}
 # Replace longer phrase then highlight, no other records touched.
 $patched=$str.Replace($old1,$new1).Replace($old2,$new2)
 if((Count $patched $old1) -ne 0 -or (Count $patched $old2) -ne 0){throw '교체 후 잔존 원문 검사 실패'}
 $outBytes=$latin.GetBytes($patched)
 New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
 [System.IO.File]::WriteAllBytes($backup,$raw)
 $temp=Join-Path $stateDir 'newgame_officer_v084_install.tmp'
 [System.IO.File]::WriteAllBytes($temp,$outBytes)
 try{
  if((Hash $backup) -ne (Hash $target)){throw '백업 후 원본이 변경됨'}
  Copy-Item -LiteralPath $temp -Destination $target -Force
  $rec=[ordered]@{game=$GamePath;originalHash=(Hash $backup);patchedHash=(Hash $target)}
  $rec | ConvertTo-Json | Set-Content -LiteralPath $state -Encoding UTF8
 }catch{
  if((Test-Path $backup) -and ((Hash $target) -ne (Hash $backup))){Copy-Item -LiteralPath $backup -Destination $target -Force}
  throw
 }finally{if(Test-Path $temp){Remove-Item -LiteralPath $temp -Force}}
 'APPLIED_2_RULES';exit 0
}
if(!(Test-Path -LiteralPath $state)){throw '설치 기록 없음'}
$prev=Get-Content -LiteralPath $state -Raw -Encoding UTF8 | ConvertFrom-Json
if($prev.game -ne $GamePath){throw '다른 게임 경로 백업 기록'}
if(!(Test-Path -LiteralPath $backup) -or (Hash $backup) -ne $prev.originalHash){throw '복원할 원본 백업 손상'}
if($Action -eq 'status'){
 if((Hash $target) -eq $prev.patchedHash){'PATCHED';exit 0}
 if((Hash $target) -eq $prev.originalHash){'VANILLA';exit 0}
 'UNKNOWN';exit 3
}
if((Hash $target) -ne $prev.patchedHash){throw '현재 파일이 관리 중인 패치본과 다르므로 자동 복원 금지'}
Copy-Item -LiteralPath $backup -Destination $target -Force
if((Hash $target) -ne $prev.originalHash){throw '복원 검증 실패'}
Remove-Item -LiteralPath $state -Force
Remove-Item -LiteralPath $backup -Force
'RESTORED';exit 0
